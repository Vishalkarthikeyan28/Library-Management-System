package com.adityachandel.booklore.model.enums;

public enum MergeMetadataType {
    authors,
    categories,
    moods,
    tags,
    series,
    publishers,
    languages
}
