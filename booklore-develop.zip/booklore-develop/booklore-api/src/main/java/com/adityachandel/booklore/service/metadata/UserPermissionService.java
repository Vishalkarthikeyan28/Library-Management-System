package com.adityachandel.booklore.service.metadata;

public class UserPermissionService {
}
