package com.adityachandel.booklore.model.enums;

public enum TaskStatus {
    IN_PROGRESS,
    CANCELLED,
    COMPLETED,
    FAILED
}

