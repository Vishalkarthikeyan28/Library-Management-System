package com.adityachandel.booklore.model.enums;

public enum KoboBookFormat {
    EPUB3,
    KEPUB,
}
