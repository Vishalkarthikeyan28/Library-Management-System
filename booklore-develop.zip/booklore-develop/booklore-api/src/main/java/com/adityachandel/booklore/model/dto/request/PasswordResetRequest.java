package com.adityachandel.booklore.model.dto.request;

import lombok.Data;

@Data
public class PasswordResetRequest {
    private String password;
}
