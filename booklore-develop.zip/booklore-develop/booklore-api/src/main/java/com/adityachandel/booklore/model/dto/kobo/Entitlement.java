package com.adityachandel.booklore.model.dto.kobo;

public interface Entitlement {
}
