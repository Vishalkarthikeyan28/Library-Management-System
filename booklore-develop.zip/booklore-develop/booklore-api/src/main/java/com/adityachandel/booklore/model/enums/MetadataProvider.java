package com.adityachandel.booklore.model.enums;

public enum MetadataProvider {
    Amazon, GoodReads, Google, Hardcover, Comicvine, Douban
}
