package com.adityachandel.booklore.model.enums;

public enum MetadataFetchTaskStatus {
    IN_PROGRESS,
    COMPLETED,
    ERROR,
    CANCELLED,
}
