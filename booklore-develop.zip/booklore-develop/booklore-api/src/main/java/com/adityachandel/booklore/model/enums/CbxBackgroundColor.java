package com.adityachandel.booklore.model.enums;

public enum CbxBackgroundColor {
    GRAY,
    BLACK,
    WHITE
}
