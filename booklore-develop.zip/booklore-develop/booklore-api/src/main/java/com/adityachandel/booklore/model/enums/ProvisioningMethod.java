package com.adityachandel.booklore.model.enums;

public enum ProvisioningMethod {
    LOCAL, OIDC, REMOTE
}
