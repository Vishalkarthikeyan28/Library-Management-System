package com.adityachandel.booklore.model.enums;

public enum NewPdfPageSpread {
    EVEN,
    ODD
}
