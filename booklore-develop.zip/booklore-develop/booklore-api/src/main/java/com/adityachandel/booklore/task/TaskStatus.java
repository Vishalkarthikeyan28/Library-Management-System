package com.adityachandel.booklore.task;

public enum TaskStatus {
    ACCEPTED,
    IN_PROGRESS,
    COMPLETED,
    FAILED,
    CANCELLED
}
