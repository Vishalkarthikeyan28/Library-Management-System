package com.adityachandel.booklore.model.dto.progress;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class KoProgress {
    private Float percentage;
}
