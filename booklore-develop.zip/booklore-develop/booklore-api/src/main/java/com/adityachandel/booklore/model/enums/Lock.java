package com.adityachandel.booklore.model.enums;

public enum Lock {
    LOCK, UNLOCK
}
