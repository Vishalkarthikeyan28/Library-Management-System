package com.adityachandel.booklore.model.enums;

public enum SortDirection {
    ASCENDING, DESCENDING
}
