package com.adityachandel.booklore.model.enums;

public enum CbxPageViewMode {
    SINGLE_PAGE,
    TWO_PAGE
}
