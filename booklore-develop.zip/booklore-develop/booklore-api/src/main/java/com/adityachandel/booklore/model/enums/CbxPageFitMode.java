package com.adityachandel.booklore.model.enums;

public enum CbxPageFitMode {
    ACTUAL_SIZE,
    FIT_PAGE,
    FIT_WIDTH,
    FIT_HEIGHT,
    AUTO
}
