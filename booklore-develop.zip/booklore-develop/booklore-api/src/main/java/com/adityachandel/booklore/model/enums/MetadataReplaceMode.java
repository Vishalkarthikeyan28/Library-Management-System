package com.adityachandel.booklore.model.enums;

public enum MetadataReplaceMode {
    REPLACE_ALL,
    REPLACE_MISSING
}
