package com.adityachandel.booklore.model.enums;

public enum FileProcessStatus {
    NEW,
    DUPLICATE,
    UPDATED
}
