package com.adityachandel.booklore.model.enums;

public enum ResetProgressType {
    BOOKLORE, KOREADER
}
