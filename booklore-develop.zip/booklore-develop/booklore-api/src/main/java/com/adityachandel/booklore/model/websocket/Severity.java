package com.adityachandel.booklore.model.websocket;


public enum Severity {
    INFO,
    WARN,
    ERROR
}
