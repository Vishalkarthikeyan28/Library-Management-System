package com.adityachandel.booklore.model.enums;

public enum NewPdfPageViewMode {
    SINGLE_PAGE,
    TWO_PAGE
}
