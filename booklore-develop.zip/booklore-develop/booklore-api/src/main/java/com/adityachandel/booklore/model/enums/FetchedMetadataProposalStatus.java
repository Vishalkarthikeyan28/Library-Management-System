package com.adityachandel.booklore.model.enums;

public enum FetchedMetadataProposalStatus {
    FETCHED,
    ACCEPTED,
    REJECTED
}
