package com.adityachandel.booklore.model.enums;

public enum CbxPageScrollMode {
    PAGINATED,
    INFINITE
}
