package com.adityachandel.booklore.model.enums;

public enum AdditionalFileType {
    ALTERNATIVE_FORMAT, SUPPLEMENTARY
}