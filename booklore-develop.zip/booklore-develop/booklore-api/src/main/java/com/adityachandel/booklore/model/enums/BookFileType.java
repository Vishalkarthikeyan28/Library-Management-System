package com.adityachandel.booklore.model.enums;

public enum BookFileType {
    PDF, EPUB, CBX
}
